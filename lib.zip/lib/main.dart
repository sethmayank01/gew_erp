import 'package:flutter/material.dart';
import 'routes.dart';
import 'screens/login_screen.dart';
import 'package:flutter/foundation.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  Widget build(BuildContext context) {
    return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'GEW ERP 1.1',
      theme: ThemeData(primarySwatch: Colors.blue),
      routerConfig: router,
    );
  }

  /*return MaterialApp.router(
      debugShowCheckedModeBanner: false,
      title: 'Test Report App',
      theme: ThemeData(primarySwatch: Colors.blue),
      routerConfig: router,
    );*/
}
