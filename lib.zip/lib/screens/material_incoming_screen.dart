import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MaterialIncomingScreen extends StatefulWidget {
  const MaterialIncomingScreen({super.key});

  @override
  State<MaterialIncomingScreen> createState() => _MaterialIncomingScreenState();
}

class _MaterialIncomingScreenState extends State<MaterialIncomingScreen> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedMaterial;
  String? _type;
  String? _subtype;
  String? _selectedJob;
  bool _isJobSpecific = false;

  final _qtyController = TextEditingController();
  final _priceController = TextEditingController();
  final _makeController = TextEditingController();
  final _descController = TextEditingController();
  final _invoiceController = TextEditingController();

  List<Map<String, dynamic>> _materialsRaw = [];
  List<String> _materials = [];
  List<String> _jobNumbers = [];
  List<Map<String, dynamic>> _entries = [];

  String _role = '';
  String _username = '';

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadEntries();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _role = prefs.getString('role')?.toLowerCase() ?? 'user';
      _username = prefs.getString('username') ?? '';
    });
  }

  Future<void> _loadData() async {
    final materials = await ApiService.getMaterials();
    final jobs = await ApiService.getOpenJobs();
    setState(() {
      _materialsRaw = List<Map<String, dynamic>>.from(materials);
      _materials = materials
          .map<String>((m) => "${m['type']} - ${m['subtype']}")
          .toList();

      _jobNumbers =
          jobs.map<String>((job) => job['serialNo'].toString()).toList();
    });
  }

  Future<void> _loadEntries() async {
    final data = await ApiService.getMaterialIncomingEntries();
    setState(() => _entries = List<Map<String, dynamic>>.from(data));
  }

  void _handleMaterialSelection(String? value) {
    if (value == null) return;

    final parts = value.split(" - ");
    final material = _materialsRaw.firstWhere(
        (m) => m['type'] == parts[0] && m['subtype'] == parts[1],
        orElse: () => {});
    setState(() {
      _type = parts[0];
      _subtype = parts[1];
      _selectedMaterial = value;
      _isJobSpecific = material['jobSpecific'] ?? false;
      _selectedJob = null; // Reset job on material change
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    final data = {
      'material': _selectedMaterial,
      'type': _type,
      'subtype': _subtype,
      'jobSpecific': _isJobSpecific,
      'serialNo': _isJobSpecific ? _selectedJob : null,
      'quantity': _qtyController.text,
      'price': _priceController.text,
      'make': _makeController.text,
      'description': _descController.text,
      'invoice': _invoiceController.text,
      'entryDate': DateTime.now().toIso8601String(),
      'user': _username,
    };

    await ApiService.submitMaterialIncoming(data);
    await ApiService.updateStock(data: data); // <-- Add this line
    await _loadEntries();
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Material entry submitted")));
    _formKey.currentState!.reset();
    setState(() {
      _selectedMaterial = null;
      _selectedJob = null;
    });
  }

  Future<void> _deleteEntry(String id, String user) async {
    if (_role == "admin" || user == _username) {
      try {
        // 1. Fetch the material entry details before deleting
        final entry = await ApiService.getMaterialEntryById(id);

        if (entry != null) {
          // 2. Reduce stock using this entry
          await ApiService.updateStock(
              data: entry, reduce: true, isDelete: true);

          // 3. Delete the entry
          await ApiService.deleteMaterialEntry(id);

          // 4. Reload entries
          await _loadEntries();
        }
      } catch (e) {
        print('Error deleting entry: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Material Incoming')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: ListView(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          value: _selectedMaterial,
                          items: _materials
                              .map((mat) => DropdownMenuItem(
                                  value: mat, child: Text(mat)))
                              .toList(),
                          onChanged: _handleMaterialSelection,
                          decoration: const InputDecoration(
                            labelText: 'Material Type',
                            border: OutlineInputBorder(),
                          ),
                          validator: (val) => val == null ? 'Required' : null,
                        ),
                      ),
                      const SizedBox(width: 10),
                      if (_isJobSpecific)
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _selectedJob,
                            items: _jobNumbers
                                .map((job) => DropdownMenuItem(
                                    value: job, child: Text(job)))
                                .toList(),
                            onChanged: (val) =>
                                setState(() => _selectedJob = val),
                            decoration: const InputDecoration(
                              labelText: 'Job Number',
                              border: OutlineInputBorder(),
                            ),
                            validator: (val) => val == null ? 'Required' : null,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _qtyController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'Quantity',
                            border: OutlineInputBorder(),
                          ),
                          validator: (val) {
                            if (val == null || val.isEmpty) return 'Required';
                            final parsed = double.tryParse(val);
                            if (parsed == null) return 'Enter valid number';
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          controller: _priceController,
                          keyboardType: const TextInputType.numberWithOptions(
                              decimal: true),
                          decoration: const InputDecoration(
                            labelText: 'Price',
                            border: OutlineInputBorder(),
                          ),
                          validator: (val) {
                            if (val == null || val.isEmpty) return 'Required';
                            final parsed = double.tryParse(val);
                            if (parsed == null) return 'Enter valid number';
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: _makeController,
                          decoration: const InputDecoration(
                            labelText: 'Make',
                            border: OutlineInputBorder(),
                          ),
                          validator: (val) => val == null || val.trim().isEmpty
                              ? 'Required'
                              : null,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextFormField(
                          controller: _descController,
                          decoration: const InputDecoration(
                            labelText: 'Description',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _invoiceController,
                    decoration: const InputDecoration(
                      labelText: 'Invoice Number',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _submit,
                    child: const Text('Submit'),
                  ),
                ],
              ),
            ),
            const Divider(height: 30),
            const Text('Incoming Entries', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 8),
            ..._entries.map((entry) => Card(
                  child: ListTile(
                    title: Text(entry['material'] ?? ''),
                    subtitle: Text(
                        "Qty: ${entry['quantity']} | Serial No: ${entry['serialNo']} | Price: ${entry['price']} | Make: ${entry['make']} | Invoice No: ${entry['invoice']} | Entry Date: ${entry['entryDate']} | User: ${entry['user']}"),
                    trailing: (_role == "admin" || entry['user'] == _username)
                        ? IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () =>
                                _deleteEntry(entry['id'], entry['user']),
                          )
                        : null,
                  ),
                )),
          ],
        ),
      ),
    );
  }
}
