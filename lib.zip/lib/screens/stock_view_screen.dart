import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class StockViewScreen extends StatefulWidget {
  const StockViewScreen({super.key});

  @override
  State<StockViewScreen> createState() => _StockViewScreenState();
}

class _StockViewScreenState extends State<StockViewScreen> {
  List<Map<String, dynamic>> _generalStock = [];
  List<Map<String, dynamic>> _jobStock = [];

  List<String> _jobNumbers = [];
  List<Map<String, dynamic>> _indentStocks = [];
  String _selectedJob = '';
  String _role = 'user';
  bool _isLoading = false;
  Map<String, int?> _editIndex = {'general': null, 'job': null};
  Map<String, List<Map<String, dynamic>>> _allIndentStocks = {};
  // Sorting
  bool _generalSortByTotal = false;
  bool _generalSortAsc = true;
  bool _jobSortByTotal = false;
  bool _jobSortAsc = true;
  bool _indentSortByValue = true;
  bool _indentSortAsc = true;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    await _loadUser();
    await _loadStock();
    await _loadJobs();
    //   await _loadAllIndentData();
  }

  Future<void> _loadUser() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _role = prefs.getString('role')?.toLowerCase() ?? 'user';
    });
  }

  Future<void> _loadAllIndentData() async {
    for (var job in _jobNumbers) {
      final indents = await ApiService.getIndentsForJob(job);
      _allIndentStocks[job] = List<Map<String, dynamic>>.from(indents);
    }
  }

  Future<void> _loadStock() async {
    setState(() => _isLoading = true);
    final general = await ApiService.getStock(false);
    final job = await ApiService.getStock(true);

    setState(() {
      _generalStock = List<Map<String, dynamic>>.from(general);
      _jobStock = List<Map<String, dynamic>>.from(job);
    });
  }

  Future<void> _loadJobs() async {
    final jobs = await ApiService.getOpenJobs();
    final nonFinalizedJobs =
        jobs.map<String>((job) => job['serialNo'].toString()).toList();
    setState(() => _jobNumbers = nonFinalizedJobs);
    // Fetch indents for all jobs and cache
    for (var jobNo in nonFinalizedJobs) {
      final indents = await ApiService.getIndentsForJob(jobNo);
      _allIndentStocks[jobNo] = List<Map<String, dynamic>>.from(indents);
    }
    setState(() => _isLoading = false);
  }

  Future<void> _loadIndentStock(String jobNo) async {
    final indents = await ApiService.getIndentsForJob(jobNo);
    final filtered = indents.toList();
    final Map<String, Map<String, dynamic>> grouped = {};
    for (var entry in filtered) {
      final key = '${entry['type']}-${entry['subtype']}';
      if (!grouped.containsKey(key)) {
        grouped[key] = {
          'type': entry['type'],
          'subtype': entry['subtype'],
          'quantity': entry['issuedQty'] ?? 0.0,
          'indentQuantity': entry['indentQuantity'] ?? 0.0,
          'price': entry['price'] ?? 0.0
        };
      } else {
        grouped[key]!['quantity'] += entry['issuedQty'] ?? 0.0;
      }
    }
    setState(() => _indentStocks = grouped.values.toList());
  }

  double _calculateTotal(List<Map<String, dynamic>> stock) {
    return stock.fold(0.0, (sum, item) {
      final qty = item['quantity'] ?? 0.0;
      final price = item['price'] ?? 0.0;
      return sum + (qty * price);
    });
  }

  double _calculateTotalIndentAllJobs() {
    double total = 0.0;
    _allIndentStocks.forEach((jobNo, entries) {
      for (var entry in entries) {
        final qty = entry['issuedQty'] ?? 0.0;
        final price = entry['price'] ?? 0.0;
        total += qty * price;
      }
    });
    return total;
  }

  Widget _buildIndentList() {
    // Use a Map to group and sum issuedQty * price per job
    Map<String, double> jobIssuedValues = {};

    for (var job in _jobNumbers) {
      jobIssuedValues[job] = 0.0;
    }

    for (var job in _jobNumbers) {
      final indents = _allIndentStocks[job] ?? [];
      for (var entry in indents) {
        final qty = entry['issuedQty'] ?? 0.0;
        final price = entry['price'] ?? 0.0;
        jobIssuedValues[job] = jobIssuedValues[job]! + qty * price;
      }
    }

    // Convert map to list for sorting
    List<Map<String, dynamic>> jobSummary = jobIssuedValues.entries
        .map((e) => {'job': e.key, 'value': e.value})
        .toList();

    // Apply sorting
    if (_indentSortByValue) {
      jobSummary.sort((a, b) => _indentSortAsc
          ? a['value'].compareTo(b['value'])
          : b['value'].compareTo(a['value']));
    } else {
      jobSummary.sort((a, b) => _indentSortAsc
          ? a['job'].compareTo(b['job'])
          : b['job'].compareTo(a['job']));
    }

    return ExpansionTile(
      title: Text(
        "Indent Stock for Non-Finalized Jobs (Total ₹${jobIssuedValues.values.fold(0.0, (a, b) => a + b).toStringAsFixed(2)})",
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _indentSortByValue = false;
                          _indentSortAsc = !_indentSortAsc;
                        });
                      },
                      child: Row(
                        children: [
                          const Text("Job No.",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 4),
                          Icon(
                            !_indentSortByValue
                                ? (_indentSortAsc
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward)
                                : Icons.unfold_more,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _indentSortByValue = true;
                          _indentSortAsc = !_indentSortAsc;
                        });
                      },
                      child: Row(
                        children: [
                          const Text("Issued Value",
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 4),
                          Icon(
                            _indentSortByValue
                                ? (_indentSortAsc
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward)
                                : Icons.unfold_more,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              const Divider(),
              ...jobSummary.map((entry) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: Row(
                    children: [
                      Expanded(child: Text(entry['job'])),
                      Expanded(
                          child: Text(
                              "₹${(entry['value'] as double).toStringAsFixed(2)}")),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _updateStock(
      bool isJobStock, int index, Map<String, dynamic> updatedItem) async {
    final stockList = isJobStock ? _jobStock : _generalStock;
    stockList[index] = updatedItem;
    await ApiService.saveStock(stockList, isJobStock);
    setState(() {
      _editIndex[isJobStock ? 'job' : 'general'] = null;
    });
  }

  Future<void> _deleteStockItem(bool isJobStock, String stockKey) async {
    final stockList = isJobStock ? _jobStock : _generalStock;
    Map<String, dynamic> stock =
        stockList.firstWhere((item) => item['key'] == stockKey);

    await ApiService.deleteStock(stock, isJobStock);
    stockList.removeWhere((item) => item['key'] == stockKey);
    setState(() {});
  }

  Widget _buildStockRow(Map<String, dynamic> item, int index, bool isJobStock) {
    final isEditing = _editIndex[isJobStock ? 'job' : 'general'] == index;
    final quantity = item['quantity'] ?? 0.0;
    final indentQuantity = item['indentQuantity'] ?? 0.0;
    final unitPrice = item['price'] ?? 0.0;
    final total = quantity * unitPrice;
    final name = '${item['type']}-${item['subtype']}';

    TextEditingController qtyController =
        TextEditingController(text: quantity.toString());
    TextEditingController priceController =
        TextEditingController(text: unitPrice.toString());
    TextEditingController indentqtyController =
        TextEditingController(text: indentQuantity.toString());

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(flex: 2, child: Text(name)),
          if (isJobStock)
            Expanded(
              child: Text(
                item['serialNo']?.toString() ?? '',
                //style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          Expanded(
            child: isEditing
                ? TextField(
                    controller: qtyController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(isDense: true),
                  )
                : Text(quantity.toString()),
          ),
          Expanded(
            child: isEditing
                ? TextField(
                    controller: indentqtyController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(isDense: true),
                  )
                : Text(indentQuantity.toString()),
          ),
          Expanded(
            child: isEditing
                ? TextField(
                    controller: priceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(isDense: true),
                  )
                : Text(unitPrice.toString()),
          ),
          Expanded(child: Text('₹${total.toStringAsFixed(2)}')),
          if (_role == 'admin')
            isEditing
                ? Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.check, color: Colors.green),
                        onPressed: () {
                          final newQty =
                              double.tryParse(qtyController.text) ?? quantity;
                          final newPrice =
                              double.tryParse(priceController.text) ??
                                  unitPrice;
                          _updateStock(isJobStock, index, {
                            ...item,
                            'quantity': newQty,
                            'price': newPrice,
                          });
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          setState(() {
                            _editIndex[isJobStock ? 'job' : 'general'] = null;
                          });
                        },
                      )
                    ],
                  )
                : Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit),
                        onPressed: () {
                          setState(() {
                            _editIndex[isJobStock ? 'job' : 'general'] = index;
                          });
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          final confirm = await showDialog<bool>(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text("Confirm Deletion"),
                              content: const Text(
                                  "Are you sure you want to delete this item?"),
                              actions: [
                                TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(false),
                                  child: const Text("Cancel"),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(true),
                                  child: const Text("Delete",
                                      style: TextStyle(color: Colors.red)),
                                ),
                              ],
                            ),
                          );
                          if (confirm == true) {
                            if (isJobStock)
                              _deleteStockItem(isJobStock,
                                  '${item['type']} - ${item['subtype']} - ${item['serialNo']}');
                            else {
                              _deleteStockItem(isJobStock,
                                  '${item['type']} - ${item['subtype']}');
                            }
                          }
                        },
                      ),
                    ],
                  ),
        ],
      ),
    );
  }

  Widget _buildStockSection(
      String title, List<Map<String, dynamic>> stockList, bool isJobStock) {
    final sortByTotal = isJobStock ? _jobSortByTotal : _generalSortByTotal;
    final sortAsc = isJobStock ? _jobSortAsc : _generalSortAsc;

    List<Map<String, dynamic>> sortedStock = [...stockList];
    sortedStock.sort((a, b) {
      if (sortByTotal) {
        double atotal = (a['quantity'] ?? 0.0) * (a['price'] ?? 0.0);
        double btotal = (b['quantity'] ?? 0.0) * (b['price'] ?? 0.0);
        return sortAsc ? atotal.compareTo(btotal) : btotal.compareTo(atotal);
      } else {
        String aname =
            (a['type'] + '-' + a['subtype'] ?? '').toString().toLowerCase();
        String bname =
            (b['type'] + '-' + b['subtype'] ?? '').toString().toLowerCase();
        return sortAsc ? aname.compareTo(bname) : bname.compareTo(aname);
      }
    });

    return ExpansionTile(
      title: Text(
        "$title (Total ₹${_calculateTotal(stockList).toStringAsFixed(2)})",
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          if (isJobStock) {
                            _jobSortByTotal = false;
                            _jobSortAsc = !_jobSortAsc;
                          } else {
                            _generalSortByTotal = false;
                            _generalSortAsc = !_generalSortAsc;
                          }
                        });
                      },
                      child: Row(
                        children: [
                          const Text('Material',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 4),
                          Icon(
                            (isJobStock
                                    ? !_jobSortByTotal
                                    : !_generalSortByTotal)
                                ? (sortAsc
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward)
                                : Icons.unfold_more,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (isJobStock)
                    const Expanded(
                      child: Text('Serial No.',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                  const Expanded(
                      child: Text('Qty',
                          style: TextStyle(fontWeight: FontWeight.bold))),
                  const Expanded(
                      child: Text('Indent Qty',
                          style: TextStyle(fontWeight: FontWeight.bold))),
                  const Expanded(
                      child: Text('Unit Price',
                          style: TextStyle(fontWeight: FontWeight.bold))),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          if (isJobStock) {
                            _jobSortByTotal = true;
                            _jobSortAsc = !_jobSortAsc;
                          } else {
                            _generalSortByTotal = true;
                            _generalSortAsc = !_generalSortAsc;
                          }
                        });
                      },
                      child: Row(
                        children: [
                          const Text('Total',
                              style: TextStyle(fontWeight: FontWeight.bold)),
                          const SizedBox(width: 4),
                          Icon(
                            (isJobStock ? _jobSortByTotal : _generalSortByTotal)
                                ? (sortAsc
                                    ? Icons.arrow_upward
                                    : Icons.arrow_downward)
                                : Icons.unfold_more,
                            size: 16,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(width: 60),
                ],
              ),
              const Divider(),
              ...sortedStock.asMap().entries.map(
                    (entry) =>
                        _buildStockRow(entry.value, entry.key, isJobStock),
                  ),
            ],
          ),
        )
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final generalTotal = _calculateTotal(_generalStock);
    final jobTotal = _calculateTotal(_jobStock);
    final indentTotal = _calculateTotalIndentAllJobs();
    final grandTotal = generalTotal + jobTotal + indentTotal;

    return Scaffold(
      appBar: AppBar(title: const Text('Stock Overview')),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {
                await _loadStock();
              },
              child: ListView(
                padding: const EdgeInsets.all(10),
                children: [
                  Card(
                    color: Colors.blue.shade50,
                    child: ListTile(
                      title: const Text("Grand Total"),
                      subtitle: Text("₹${grandTotal.toStringAsFixed(2)}",
                          style: const TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 18)),
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildStockSection("General Stock", _generalStock, false),
                  const SizedBox(height: 10),
                  _buildStockSection("Job-Specific Stock", _jobStock, true),
                  const SizedBox(height: 10),
                  _buildIndentList(),
                  const SizedBox(height: 10),
                  /*_buildIndentStockSection(),
                  if (_selectedJob.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 8.0),
                      child: Text(
                        'Indent Stock Total for $_selectedJob: ₹${indentTotal.toStringAsFixed(2)}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),*/
                ],
              ),
            ),
    );
  }
}
