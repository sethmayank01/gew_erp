import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _db;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDatabase();
    return _db!;
  }

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, 'gew_erp.db');
    return await openDatabase(path);
  }

  Future<List<Map<String, dynamic>>> getJobs() async {
    final db = await database;
    return await db.query('jobs');
  }

  Future<List<Map<String, dynamic>>> getOpenJobs() async {
    final db = await database;
    return await db.query('jobs', where: 'is_final = 0');
  }

  Future<List<Map<String, dynamic>>> getMaterials() async {
    final db = await database;
    return await db.query('materials');
  }

  Future<List<Map<String, dynamic>>> getStock(bool isJobSpecific) async {
    final db = await database;
    if (isJobSpecific) {
      return await db.query('stock', where: 'serial_no IS NOT NULL');
    } else {
      return await db.query('stock', where: 'serial_no IS NULL');
    }
  }

  Future<void> updateStockQuantity(
      int materialId, String? serialNo, double deltaQty) async {
    final db = await database;
    final result = await db.query('stock',
        where: 'material_id = ? AND (serial_no IS ? OR serial_no = ?)',
        whereArgs: [materialId, serialNo, serialNo]);

    if (result.isNotEmpty) {
      final item = result.first;
      double updatedQty = (item['quantity'] as double) + deltaQty;
      await db.update(
        'stock',
        {'quantity': updatedQty},
        where: 'id = ?',
        whereArgs: [item['id']],
      );
    }
  }

  Future<List<Map<String, dynamic>>> getIndentsForJob(String serialNo) async {
    final db = await database;
    return await db
        .query('job_indents', where: 'serial_no = ?', whereArgs: [serialNo]);
  }

  Future<void> insertMaterialIndent(Map<String, dynamic> indent) async {
    final db = await database;
    await db.insert('job_indents', indent,
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> issueMaterial(Map<String, dynamic> item) async {
    final db = await database;
    final serialNo = item['serialNo'];
    final type = item['type'];
    final subtype = item['subtype'];
    final issueQty = item['issue_qty'] as double;

    final material = await db.query('materials',
        where: 'type = ? AND subtype = ?', whereArgs: [type, subtype]);
    if (material.isEmpty) return;

    final materialId = material.first['id'] as int;

    // Update job_indent
    final indentEntry = await db.query('job_indents',
        where: 'serial_no = ? AND material_id = ?',
        whereArgs: [serialNo, materialId]);
    if (indentEntry.isNotEmpty) {
      final existing = indentEntry.first;
      final newIssuedQty =
          (existing['issued_qty'] as double? ?? 0.0) + issueQty;
      final unitPrice = (await db.query('stock',
              where: 'material_id = ? AND serial_no = ?',
              whereArgs: [materialId, serialNo]))
          .first['price'];
      final issuedValue = newIssuedQty * (unitPrice as double);

      await db.update('job_indents',
          {'issued_qty': newIssuedQty, 'issued_value': issuedValue},
          where: 'id = ?', whereArgs: [existing['id']]);
    }

    // Reduce from stock
    await updateStockQuantity(materialId, serialNo, -issueQty);
  }
}
